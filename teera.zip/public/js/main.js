$(document).on("click", "#hamberger", function(e){
    e.preventDefault();
    $('.mobile-menu').toggleClass('active');
})